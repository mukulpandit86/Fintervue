# AI Interview

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mukul-Pandit/pen/mdZbZBL](https://codepen.io/Mukul-Pandit/pen/mdZbZBL).

