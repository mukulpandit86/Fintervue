# Virtual interview page

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mukul-Pandit/pen/RwzbzWL](https://codepen.io/Mukul-Pandit/pen/RwzbzWL).

